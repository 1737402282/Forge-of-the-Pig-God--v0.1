========================================
 诸神之锻炉 · 猪猪投影 材质包 (Pig Star)
========================================

适用：GTNH (GregTech New Horizons) — Minecraft 1.7.10

【效果】
- 诸神之锻炉 (Forge of the Gods)：机器中央的恒星投影变成 GIF 粉色小猪
  （始终面向玩家的扁平全息投影，约 14 格，完整可见）
- 鸿蒙之眼 (Eye of Harmony)：中央恒星【隐藏】（不显示），
  空间壳与行星轨道保持原样

【安装方法】（在其他电脑上也一样）
1. 找到 GTNH 实例的材质包文件夹：<实例根目录>\.minecraft\resourcepacks\
   （Prism Launcher / MultiMC 通常在这里；GTNH 官方启动器也类似）
2. 把本压缩包【整个】放进该文件夹（不要解压，zip 即可；解压成文件夹也可以）
3. 启动游戏 → 选项 → 资源包 (Resource Packs) → 把
   "ForgeOfGods-PigStar" 移到已启用列表（或直接确认已在列表中）
4. 若游戏已在运行：按 F3+T 重载资源，或重启游戏

【注意】
- 纯客户端材质包，服务器无需任何改动
- 依赖 GTNH 内的 TecTech / GregTech 渲染器；在其他版本/整合包上可能无效
- 若与其他材质包冲突，把本包放在资源包列表最上方

【自定义（可选）】
- 猪的大小：解压后改 assets/tectech/shaders/star.vert*.glsl 里的 QW/QH
  （默认 1.2 = 星体半径的 1.2 倍）
- 换猪的图片：替换 assets/tectech/models/StarLayer0.png（透明背景，猪居中，
  占画面宽度约 60%，正方形 1:1）
- 想恢复 EOH 恒星：删除 assets/gregtech/shaders/textured.frag*.glsl
========================================
